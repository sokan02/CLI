//
// Created by sofija on 27/05/25.
//

#ifndef COMMAND_H
#define COMMAND_H
#include <string>

struct IInput {
    virtual void setInput(std::istream* in) = 0;
    virtual ~IInput() = default;
};

struct IOutput {
    virtual void setOutput(std::ostream* out) = 0;
    virtual ~IOutput() = default;
};

class Command {
public:
        Command(const std::string& arg, const std::string& opt);
        virtual void execute() = 0;
protected:
    std::string m_arg;
    std::string m_opt;
    bool isFile();
    std::string noQuotation(std::string text);
    std::string readConsole();
    std::string readFile();
};

#endif //COMMAND_H
