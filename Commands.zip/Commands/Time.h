//
// Created by sofija on 24/02/26.
//

#ifndef TIME_H
#define TIME_H
#include "Command.h"

class Time : public Command {
public:
    void execute() override;
    Time(const std::string& arg, const std::string& opt);
};


#endif //TIME_H
