//
// Created by sofija on 24/02/26.
//

#ifndef WC_H
#define WC_H
#include "Command.h"

class Wc : public Command {
public:
    void execute() override;
    Wc(const std::string& arg, const std::string& opt);
    int countWords(std::string text);
    int countCharacters(std::string text);
};

#endif //WC_H
