//
// Created by sofija on 24/02/26.
//

#ifndef TR_H
#define TR_H
#include "Command.h"

class Tr : public Command {
public:
    Tr(const std::string& arg, const std::string& opt, const std::string& with);
    void execute() override;
    void replaceAll(std::string& str, const std::string& from, const std::string& to);

private:
    std::string with;
    std::string getWhat();
};

#endif //TR_H
