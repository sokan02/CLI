//
// Created by sofija on 24/02/26.
//

#ifndef ECHO_H
#define ECHO_H
#include <string>
#include "Command.h"

class Echo : public Command {
public:
    void execute() override;
    Echo(const std::string& arg, const std::string& opt);
};

#endif //ECHO_H
