//
// Created by sofija on 24/02/26.
//
#include "Wc.h"
#include <iterator>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <ostream>
#include <iomanip>
#include <cstring>


Wc::Wc(const std::string &arg, const std::string &opt) : Command(arg, opt) {}

int Wc::countWords(std::string text) {
    int cnt = 0;
    bool lastLetter = false;

    for (char c : text) {
        if (isspace(c)) {
            lastLetter = false;
        }
        else {
            if (!lastLetter) cnt++;
            lastLetter = true;
        }
    }
    return cnt;
}

int Wc::countCharacters(std::string text) {
    int cnt = 0;
    for (char c : text) cnt++;
    return cnt;
}


void Wc::execute() {
    if (m_opt == "-w") {
        if (m_arg == "") {
            std::cout << countWords(this->readConsole()) << std::endl;
            return;
        }

        if (!this->isFile())
            std::cout << this->countWords(this->noQuotation(this->m_arg)) << std::endl;

        else
            std::cout << this->countWords(this->readFile()) << std::endl;
    }
    else if (m_opt == "-c") {

        if (m_arg == "") {
            std::cout << countCharacters(this->readConsole()) << std::endl;
            return;
        }

        if (!this->isFile())
            std::cout << this->countCharacters(this->noQuotation(this->m_arg)) << std::endl;

        else
            std::cout << this->countCharacters(this->readFile()) << std::endl;
    }
    else {
        std::cout << "Error - unknown option: " << m_opt << std::endl;
    }
}

