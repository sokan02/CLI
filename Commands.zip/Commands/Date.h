//
// Created by sofija on 24/02/26.
//

#ifndef DATE_H
#define DATE_H
#include "Command.h"

class Date : public Command {
public:
    Date(const std::string& arg, const std::string& opt);
    void execute() override;
};

#endif //DATE_H
