//
// Created by sofija on 24/02/26.
//

#include "Echo.h"
#include <iostream>
#include <fstream>
#include <ostream>
#include <iomanip>

Echo::Echo(const std::string &arg, const std::string &opt) : Command(arg, opt) {}

void Echo::execute() {
    if (m_opt != "") {
        std::cout << "Error - echo cannot have an option" << std::endl;
        return;
    }
    if (m_arg == "") {
        std::cout << readConsole() << std::endl;
        return;
    }
    if (!this->isFile()) {
        std::cout << this->noQuotation(this->m_arg) << std::endl;
    }
    else {
        std::cout << readFile() << std::endl;
    }
}