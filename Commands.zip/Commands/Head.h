//
// Created by sofija on 24/02/26.
//

#ifndef HEAD_H
#define HEAD_H
#include "Command.h"

class Head : public Command {
public:
    Head(const std::string& arg, const std::string& opt);
    void execute() override;
    int getNoRows();
    std::string getLines(int noLines, std::string text);
};

#endif //HEAD_H
