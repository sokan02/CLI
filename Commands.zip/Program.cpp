//
// Created by sofija on 13/01/26.
//
#include "Program.h"
Program::Program() : argument("$"){}

Program* Program::getInstance() {
    static Program instance;
    return &instance;
}

Program::~Program() {
    for (Command* cmd : commands) {
        delete cmd;
    }
}

void Program::add(Command* cmd) {
    commands.push_back(cmd);
    if (commands.size() == 1) it = commands.begin();
    else ++it;
}

void Program::executeNext() {
    (*it)->execute();
}

bool Program::hasNext() {
    return it != commands.end();
}

string Program::getArgument() {
    return argument;
}

void Program::setArgument(string arg) {
    argument = arg;
}