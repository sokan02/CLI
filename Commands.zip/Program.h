//
// Created by sofija on 13/01/26.
//

#ifndef PROGRAM_H
#define PROGRAM_H

#include "Commands/Command.h"
#include <list>
using namespace std;

class Program {
public:
    static Program* getInstance();
    ~Program();
    void add(Command* cmd);

    void executeNext();
    bool hasNext();

    string getArgument();
    void setArgument(string arg);

protected:
    Program();

private:
    list<Command*> commands;
    list<Command*>::iterator it;

    string argument;
};

#endif //PROGRAM_H
